import { Component } from '@angular/core';
import { Course } from './course.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  // course1:Course= new Course('React','3 Days');
  // course2:Course=new Course('Backbone','3 Days');
  url:string="https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/Angular_full_color_logo.svg/250px-Angular_full_color_logo.svg.png"
  title = '';
  listOfCourses:Course[] = [
   new Course('React','3 Days'),
    new Course('Backbone','3 Days'),
    new Course('Polymer','4 Days')
  ];
  ChangeTitle(){
    this.title = "List Of Courses !";
  }

  // courses:string[] = ['React','Node','Polymer'];

}
