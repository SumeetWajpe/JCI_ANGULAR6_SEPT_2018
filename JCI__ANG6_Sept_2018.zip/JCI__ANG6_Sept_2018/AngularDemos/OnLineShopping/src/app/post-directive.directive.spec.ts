import { PostDirectiveDirective } from './post-directive.directive';

describe('PostDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new PostDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
