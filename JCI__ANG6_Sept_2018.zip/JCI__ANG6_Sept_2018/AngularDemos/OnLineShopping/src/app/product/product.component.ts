import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Product } from '../models/product.model';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  isStyled:boolean=true;
  isFree:boolean=true;  

   @Input() productdetails:Product = new Product();
  @Input() productIndex:number=0;

  @Output() ondeleteProduct:EventEmitter<number> = new EventEmitter<number>();
  @Output() onLikeProduct:EventEmitter<number> = new EventEmitter<number>();
  @Output() onDislikeProduct:EventEmitter<number> = new EventEmitter<number>();



  DeleteProduct(theIndex:number){    
    this.ondeleteProduct.emit(theIndex);// emit the event !
}

DislikeProduct(){
  this.onDislikeProduct.emit(this.productIndex);  
}

LikeProduct(){
  this.onLikeProduct.emit(this.productIndex);

}

  constructor() { }

  ngOnInit() {
  }

}
