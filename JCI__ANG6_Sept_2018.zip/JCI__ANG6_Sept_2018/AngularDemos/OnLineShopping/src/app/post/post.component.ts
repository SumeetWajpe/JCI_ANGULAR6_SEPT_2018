import { Component, OnInit } from '@angular/core';
import { PostsService } from '../services/posts.service';
import { Post } from '../models/post.model';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css'],
  providers:[PostsService]
})
export class PostComponent implements OnInit {

  posts:Post[]=[];

  constructor(public servObj:PostsService) {
    
   }  

  ngOnInit() {
    this.servObj.getAllPosts().subscribe((response)=>{       
      this.posts = response;
     
      localStorage["posts"] = JSON.stringify(response);
    })
  }

}
