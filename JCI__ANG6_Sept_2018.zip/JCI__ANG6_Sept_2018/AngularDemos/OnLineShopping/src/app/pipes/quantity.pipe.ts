import {Pipe,PipeTransform} from '@angular/core'

@Pipe({name:'qty'})
export class QuantityPipe implements PipeTransform{
        transform(theInputQuantity:number){         
                switch(theInputQuantity){
                        case 0:
                        return "Out Of Stock!";
                        case 1:
                        return theInputQuantity + " Item";
                        default:
                        return theInputQuantity + " Items";
                }
        }
}