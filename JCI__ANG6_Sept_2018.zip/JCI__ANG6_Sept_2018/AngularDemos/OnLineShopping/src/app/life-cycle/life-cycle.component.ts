import { Component, OnInit, Input, OnChanges, AfterViewChecked, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-life-cycle',
  templateUrl: './life-cycle.component.html',
  styleUrls: ['./life-cycle.component.css']
})
export class LifeCycleComponent implements OnInit,OnChanges,AfterViewChecked {

  @Input() message:string="Initial Value !";
  constructor() {
    console.log('Within Constructor ! Message : ' + this.message);
   }
  ngOnInit() {
    console.log('Within ngOnInit ! Message : ' + this.message);
  }
  ngOnChanges(theChanges:SimpleChanges){
    console.log('Within ngOnChanges ! Message : ' + this.message);

    for(let prop in theChanges){
      console.log(`Property Name : ${prop} , 
      Current Value : ${theChanges[prop].currentValue} ,
       Previous Value : ${theChanges[prop].previousValue}`)
    }
  }

  ngAfterViewChecked(){
    console.log('Within ngAfterViewChecked !');
  }

  ngOnDestroy(){
    console.log('Within ngOnDestroy !');
  }

}
