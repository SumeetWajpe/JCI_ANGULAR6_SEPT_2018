import { Directive, ElementRef, Input, HostListener } from '@angular/core';

@Directive({
  selector: '[postStyle]'
})
export class PostDirectiveDirective {

  @Input()  postBGColor:string = "Yellow";
  constructor(public elmRef:ElementRef) { }

  ngOnInit(){
    this.elmRef.nativeElement.style.backgroundColor = this.postBGColor;
    this.elmRef.nativeElement.style.border = "2px solid red";
    this.elmRef.nativeElement.style.borderRadius = "10px";    
    this.elmRef.nativeElement.style.margin = "10px";
    this.elmRef.nativeElement.style.padding = "10px"; 

  }

  @HostListener('mouseenter') on_mouse_enter(){
    this.elmRef.nativeElement.style.backgroundColor= "orange";
    }
    @HostListener('mouseleave') on_mouse_leave(){
        this.elmRef.nativeElement.style.backgroundColor= this.postBGColor;
    }



}
