import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Post } from '../models/post.model';

@Component({
  selector: 'app-post-details',
  templateUrl: './post-details.component.html',
  styleUrls: ['./post-details.component.css']
})
export class PostDetailsComponent implements OnInit {
  thecurrPost:Post=new Post();
  postId:number=0;
  constructor(public currRoute:ActivatedRoute) { }
  ngOnInit() {
    this.currRoute.params.subscribe(p=>  this.postId = p.id);
    let allPosts = JSON.parse(localStorage["posts"]);
    this.thecurrPost = allPosts.find(p=> p.id == this.postId);    
  }

}
