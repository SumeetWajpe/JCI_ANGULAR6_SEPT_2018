import { Component, OnInit } from '@angular/core';
import {Product} from '../models/product.model';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-shopping-cart',
  templateUrl: './shopping-cart.component.html',
  styleUrls: ['./shopping-cart.component.css']
  
})
export class ShoppingCartComponent implements OnInit {

  newProduct:Product   = new Product();
  productName:string="";
  products:Product[] = [];
  constructor(public servInstance:ProductService) {
    this.products = this.servInstance.getAllProducts();// getting products 
                                                                                        // from service !
   }
  ngOnInit() {
  }

  AddProduct(theForm:any){
      // add a new Product here !
      this.newProduct.ImageUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/No_image_available.svg/480px-No_image_available.svg.png";
      this.products.push(this.newProduct);
      this.newProduct = new Product();
      theForm.reset();// resetting the form 
  }

  DeleteProductFromCart(theIndex:number){
     this.products.splice(theIndex,1);    
     // update the data on server
  }

  LikeProductFromCart(theIndex:number){
      this.products[theIndex].likes+=1;
  }

  DislikeProductFromCart(theIndex:number){
    this.products[theIndex].likes-=1;
}

  

}
