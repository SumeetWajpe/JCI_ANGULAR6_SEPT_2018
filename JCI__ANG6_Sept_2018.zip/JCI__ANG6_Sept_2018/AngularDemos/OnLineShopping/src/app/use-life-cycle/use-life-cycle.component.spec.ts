import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UseLifeCycleComponent } from './use-life-cycle.component';

describe('UseLifeCycleComponent', () => {
  let component: UseLifeCycleComponent;
  let fixture: ComponentFixture<UseLifeCycleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UseLifeCycleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UseLifeCycleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
