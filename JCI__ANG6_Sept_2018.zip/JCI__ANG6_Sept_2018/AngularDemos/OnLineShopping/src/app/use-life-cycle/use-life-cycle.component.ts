import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-use-life-cycle',
  templateUrl: './use-life-cycle.component.html',
  styleUrls: ['./use-life-cycle.component.css']
})
export class UseLifeCycleComponent implements OnInit {


  dynamicMessage:string="";
  constructor() { }

  ngOnInit() {
  }

}
