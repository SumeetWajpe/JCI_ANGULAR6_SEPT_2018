import {HttpClient} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Post } from '../models/post.model';

@Injectable()
export class PostsService{
    
    constructor(private httpObj:HttpClient){

    }
    getAllPosts():Observable<Post[]>{       
        // Make AJAX request !
        // this.httpObj.get('https://jsonplaceholder.typicode.com/posts')
        // .subscribe(
        //         function(response){
        //                return (response);
        //         }
        // )
        return this.httpObj.get<Post[]>('https://jsonplaceholder.typicode.com/posts');
       
    }
}