import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {RouterModule,Routes} from '@angular/router';

import { AppComponent } from './app.component';
import { ShoppingCartComponent } from './shopping-cart/shopping-cart.component';
import { ProductComponent } from './product/product.component';
import { QuantityPipe } from './pipes/quantity.pipe';
import { ProductService } from './services/product.service';
import { PostComponent } from './post/post.component';
import { LifeCycleComponent } from './life-cycle/life-cycle.component';
import { UseLifeCycleComponent } from './use-life-cycle/use-life-cycle.component'; 
import { PostDetailsComponent } from './post-details/post-details.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import { UserService } from './services/user.service';
import { AuthguardGuard } from './authguard.guard';
import { PostDirectiveDirective } from './post-directive.directive';

/* Initial set of routes (without gaurds) */
/* Disable gaurds if you want to use these routes */
// const routes:Routes = [
//   {path:"cart",component:ShoppingCartComponent},
//   {path:"posts",component:PostComponent},
//   {path:"lifecycle",component:UseLifeCycleComponent},
//   {path:"post/:id",component:PostDetailsComponent},
//   {path:"",redirectTo:"/cart",pathMatch:'full'},
//   {path:"**",redirectTo:"/posts"}
// ];

const routes:Routes = [ 
  {path:"",component:LoginComponent},
  {
    path:"dashboard",
    // canActivate:[AuthguardGuard],
    component:DashboardComponent,
    children:[
      {path:'',component:ShoppingCartComponent},
      {path:'posts',component:PostComponent},
      {path:'lifecycle',component:UseLifeCycleComponent},
      {path:'post/:id',component:PostDetailsComponent}


    ]
  }
];




@NgModule({
  declarations: [
    AppComponent,    ShoppingCartComponent,
    ProductComponent,    QuantityPipe, 
       PostComponent, LifeCycleComponent, 
       UseLifeCycleComponent,
       PostDetailsComponent, DashboardComponent, LoginComponent, 
       PostDirectiveDirective
  ],
  imports: [
    BrowserModule,FormsModule,HttpClientModule,
    RouterModule.forRoot(routes)
  ],
  providers:[ProductService,UserService,AuthguardGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
