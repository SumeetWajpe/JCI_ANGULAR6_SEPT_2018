let someVar:string = "Hello !";


function Product(x:any,y:any){
    return x + y;
}