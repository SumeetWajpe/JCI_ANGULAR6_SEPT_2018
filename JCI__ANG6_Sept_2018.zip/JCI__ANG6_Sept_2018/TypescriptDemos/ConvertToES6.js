let someVar = "Hello !";
function Product(x, y) {
    return x + y;
}
