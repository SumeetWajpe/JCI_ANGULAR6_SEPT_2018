var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var x = 100; // Type Inference
//x = "Hello !";
var str; // Type annotation !
var y;
var boolvar;
var o;
o = 100;
o = "Bye !";
o = { name: 'Sachin' };
o = ['BMW', 'AUDI'];
function Add(x, y) {
    if (x < 0) {
        return ' x should be greater than 0 !';
    }
    return x + y;
}
var result = Add(20, 30);
// Block scoped Variables !
var z = 1000;
if (true) {
    var z_1;
    z_1 = 2000;
    console.log("Within If : " + z_1);
    if (true) {
        console.log("Within Inner If : " + z_1);
    }
}
console.log("Outer : " + z);
var PI = 3.14; // decln + defn !
// PI = 3.14565;
// Arrays
var cars = ["BMW", "AUDI", "FERRARI"];
var moreCars = new Array('TATA', "MARUTI");
// for
// for-in
// for(let car in cars){
//     console.log(cars[car]);
// }
// for-of  (ES6)
for (var _i = 0, cars_1 = cars; _i < cars_1.length; _i++) {
    var car = cars_1[_i];
    console.log(car);
}
// cars.forEach(function(car,index){
//     console.log(index + "." + car);
// });
// Spread Operator !
var allCars = cars.concat(moreCars, ["MAHINDRA"]); // Spread The Elements of an array !
// console.log(allCars);
// Arrow Functions
// function Square(x){
//     return x * x;
// }
/// Function as an expression !
// var Square = function(x){
//     return x * x;
// }
// ES 6 
// var Square = (x) =>{
//     return x * x;
// }
// OR
var Square = function (x) { return x * x; }; // Optimized !
// cars.forEach(function(car,index){
//     console.log(index + "." + car);
// });
// cars.forEach(
//     (car,index)=> console.log(index + "." + car)  
// )
function Emp() {
    var _this = this;
    this.Salary = 200000;
    setTimeout(function () { return console.log(_this.Salary); }, 2000);
}
var Designations;
(function (Designations) {
    Designations[Designations["Developer"] = 100] = "Developer";
    Designations[Designations["Trainer"] = 101] = "Trainer";
    Designations[Designations["Architect"] = 102] = "Architect";
    Designations[Designations["Tester"] = 103] = "Tester";
})(Designations || (Designations = {}));
var myDesgn = Designations.Trainer;
console.log(myDesgn); // prints numeric value;
console.log(Designations[myDesgn]); // prints the symbolic value
var Company = /** @class */ (function () {
    function Company() {
    }
    return Company;
}());
// var company:ICompany = {name:'JCI',location:'Pune',xyz:1234}; // Error as xyz is not defined !
// Paramaters
//1.Optional
// function PrintBooks(title?:string,author?:string,noOfPages?:number){
//         console.log(title,author,noOfPages);
// }
// PrintBooks();
// PrintBooks("India 2020","Dr. APJ Abdul Kalam",400);
// 2. Default Parameters
// function PrintBooks(
//     title:string="India 2020",
// author:string="Dr. APJ Abdul Kalam",
// noOfPages:number=100){
//     console.log(title,author,noOfPages);
// }
// PrintBooks();
// PrintBooks("Wings Of Fire","Dr. APJ Abdul Kalam",300);
// 3. Rest parameters
function PrintBooks(author) {
    var titles = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        titles[_i - 1] = arguments[_i];
    }
    console.log(author, titles);
}
PrintBooks("Dr. APJ Abdul Kalam", "Wings Of Fire", "India 2020");
PrintBooks("Sachin Tendulkar", "Playing It My Way");
var Categories;
(function (Categories) {
    Categories[Categories["fiction"] = 0] = "fiction";
    Categories[Categories["autobiography"] = 1] = "autobiography";
    Categories[Categories["comedy"] = 2] = "comedy";
    Categories[Categories["romantic"] = 3] = "romantic";
})(Categories || (Categories = {}));
function GetAllBooks() {
    var books = [
        { title: "Wings Of Fire", author: "Dr. APJ Abdul Kalam", price: 900, publication: 'Jaico', category: Categories.autobiography },
        { title: "India 2020", author: "Dr. APJ Abdul Kalam", price: 800, publication: 'Westland ', category: Categories.fiction },
        { title: "Cover Drive", author: "Virat Kohli", price: 3000, publication: 'Jaico', category: Categories.autobiography },
        { title: "Mrutyunjay", author: "Ranjit Desai", price: 1000, publication: 'Westland ', category: Categories.fiction },
        { title: "I am Malala", author: "Malala", price: 2000, publication: 'Aleph ', category: Categories.autobiography }
    ];
    return books;
}
var allBooks = GetAllBooks();
// String Templates
for (var _a = 0, allBooks_1 = allBooks; _a < allBooks_1.length; _a++) {
    var book = allBooks_1[_a];
    // console.log(book.title + " is of Rs." + book.price)
    console.log(book.title + " is of Rs. " + book.price + " !");
}
var Car = /** @class */ (function () {
    function Car(name, speed) {
        if (name === void 0) { name = "i20"; }
        if (speed === void 0) { speed = 200; }
        this.name = name;
        this.speed = speed;
    }
    Car.prototype.accelerate = function () {
        return (this.name + " is running at " + this.speed + " kmph !");
    };
    return Car;
}());
var carObj = new Car();
var JamesBondCar = /** @class */ (function (_super) {
    __extends(JamesBondCar, _super);
    function JamesBondCar(name, speed, fly, nitro) {
        var _this = _super.call(this, name, speed) || this;
        _this.canFly = fly;
        _this.useNitro = nitro;
        return _this;
    }
    JamesBondCar.prototype.accelerate = function () {
        return _super.prototype.accelerate.call(this) + "Can Fly : " + this.canFly;
    };
    return JamesBondCar;
}(Car));
var jbc = new JamesBondCar("Aston Martin", 300, true, true);
console.log(jbc.accelerate());
// Enhanced Class Syntax
var EnhancedCar = /** @class */ (function () {
    function EnhancedCar(name, speed) {
        this.name = name;
        this.speed = speed;
    }
    return EnhancedCar;
}());
