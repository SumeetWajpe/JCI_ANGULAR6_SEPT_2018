var x = 100; // Type Inference
//x = "Hello !";

var str:string; // Type annotation !
var y:number;
var boolvar:boolean;
var o:any;
o = 100;
o = "Bye !";
o = {name:'Sachin'};
o = ['BMW','AUDI'];

function Add(x:number,y:number):number|string{
    if(x < 0){
        return ' x should be greater than 0 !'
    }
      return x  +y;
}

var result:number|string = Add(20,30);

// Block scoped Variables !
let z =1000;
        if(true){
        let z;
        z =2000;
        console.log("Within If : " + z); 
            if(true){
                console.log("Within Inner If : " + z);
            }        
        }

console.log("Outer : " + z);

const PI = 3.14; // decln + defn !
// PI = 3.14565;

// Arrays
var cars:string[] = ["BMW","AUDI","FERRARI"];
var moreCars:Array<string> = new Array<string>('TATA',"MARUTI");

// for
// for-in
// for(let car in cars){
//     console.log(cars[car]);
// }
// for-of  (ES6)

for(let car of cars){
    console.log(car);
}

// cars.forEach(function(car,index){
//     console.log(index + "." + car);
// });

// Spread Operator !
var allCars = [...cars,...moreCars,"MAHINDRA"]; // Spread The Elements of an array !
// console.log(allCars);

// Arrow Functions


// function Square(x){
//     return x * x;
// }

/// Function as an expression !
// var Square = function(x){
//     return x * x;
// }

// ES 6 
// var Square = (x) =>{
//     return x * x;
// }

// OR
var Square = x => x*x; // Optimized !


// cars.forEach(function(car,index){
//     console.log(index + "." + car);
// });


// cars.forEach(
//     (car,index)=> console.log(index + "." + car)  
// )

function Emp(){
    this.Salary = 200000;           
    setTimeout(()=>console.log(this.Salary),2000);           
}

enum Designations{
    Developer=100,
    Trainer,
    Architect,
    Tester
}

let myDesgn:Designations = Designations.Trainer;

console.log(myDesgn);// prints numeric value;
console.log(Designations[myDesgn]);// prints the symbolic value

// Interfaces

interface ICompany{
    name:string;
    location:string;
    getDetails?():void;
}

class Company implements ICompany{
    name:string;
    location:string;
}

// var company:ICompany = {name:'JCI',location:'Pune',xyz:1234}; // Error as xyz is not defined !

// Paramaters
//1.Optional

// function PrintBooks(title?:string,author?:string,noOfPages?:number){
//         console.log(title,author,noOfPages);
// }

// PrintBooks();
// PrintBooks("India 2020","Dr. APJ Abdul Kalam",400);


// 2. Default Parameters

// function PrintBooks(
//     title:string="India 2020",
// author:string="Dr. APJ Abdul Kalam",
// noOfPages:number=100){
   
//     console.log(title,author,noOfPages);
// }

// PrintBooks();
// PrintBooks("Wings Of Fire","Dr. APJ Abdul Kalam",300);

// 3. Rest parameters

function PrintBooks(author:string,...titles:string[]){
        console.log(author,titles);
}


PrintBooks("Dr. APJ Abdul Kalam","Wings Of Fire","India 2020");
PrintBooks("Sachin Tendulkar","Playing It My Way");


enum Categories{
    fiction,autobiography,comedy,romantic
}
interface IBook{
    title:string;
    author:string;
    price:number;
    publication:string;
    category:Categories;
}
function GetAllBooks():IBook[]{
    var books:IBook[] =  [
        {title:"Wings Of Fire",author:"Dr. APJ Abdul Kalam",price:900,publication:'Jaico',category:Categories.autobiography},
        {title:"India 2020",author:"Dr. APJ Abdul Kalam",price:800,publication:'Westland ',category:Categories.fiction},
        {title:"Cover Drive",author:"Virat Kohli",price:3000,publication:'Jaico',category:Categories.autobiography},
        {title:"Mrutyunjay",author:"Ranjit Desai",price:1000,publication:'Westland ',category:Categories.fiction},
        {title:"I am Malala",author:"Malala",price:2000,publication:'Aleph ',category:Categories.autobiography}
    ];
    return books;
}


var allBooks:IBook[] = GetAllBooks();
// String Templates
for(let book of allBooks){
    // console.log(book.title + " is of Rs." + book.price)
    console.log(`${book.title} is of Rs. ${book.price} !`)
}


class Car{
    private id:number;
    name:string;
    speed:number;

    constructor(name:string="i20",speed:number=200){
            this.name = name;
            this.speed =speed;
    }
    accelerate():string{
        return (this.name + " is running at " + this.speed + " kmph !")
    }
}

var carObj = new Car();

class JamesBondCar extends Car{
    canFly:boolean;
    useNitro:boolean;
    constructor(name:string,speed:number,fly:boolean,nitro:boolean){
        super(name,speed);
        this.canFly = fly;
        this.useNitro = nitro;
    }
    accelerate():string{
            return super.accelerate() + "Can Fly : "+ this.canFly;
    }
}

var jbc = new JamesBondCar("Aston Martin",300,true,true);
console.log(jbc.accelerate()) ;

// Enhanced Class Syntax

class EnhancedCar{
    constructor(public name:string,public speed:number){

    }
}

